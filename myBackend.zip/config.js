config = {
  options: {
    host: "45.82.79.207", //主机ip
    user: "root", //数据库 用户名
    password: "f017e836e13b5858", // 修改为你的密码
    port: "3306", //数据库端口号
    database: "xiaoexing", // 请确保数据库存在
  },
};
module.exports=config;
